﻿#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <string>
#include <sstream>
#include <stdexcept>
#include <algorithm> 

using namespace std;

const double PI = 3.14159265359;

class Aircraft {
private:
    double x, y;
    double azimuth;
    double v0;
    double r0;

public:
    Aircraft(double x0, double y0, double v0, double r0, double azimuth) : x(x0), y(y0), v0(v0), r0(r0), azimuth(azimuth){}

   void flyTo(double x_dest, double y_dest, double time, double Dt, double v0, double r0, bool& firstFly) {
       double dx;
       double dy;
       double distance;
       double time_to_dest;
       double delta_t;

       if (firstFly)
       {
           flyStraight(v0, Dt, azimuth);
       }
       else
       {
               dx = x_dest - x;
               dy = y_dest - y;
               distance = sqrt(dx * dx + dy * dy);
               time_to_dest = distance / v0;
               delta_t = time - time_to_dest;
 
           if (delta_t >= time_to_dest) {
               x += v0 * time * cos(azimuth);
               y += v0 * time * sin(azimuth);
               azimuth = atan2(dy, dx) * 180 / PI;
           }
           else
           {
               // חיגה עם רדיוס R0
               hoverWithClockwiseCircle(atan2(y, x), r0);
           }
       }
       
    }
  

    void hoverWithClockwiseCircle(double angle_to_dest, double R0) {
        // Assuming clockwise circle
        x = x + R0 * cos(angle_to_dest + PI / 2);
        y = y + R0 * sin(angle_to_dest + PI / 2);
        azimuth = (angle_to_dest + PI) * 180 / PI;
    }
    
    // פונקציה לטיסה ישירה
    void flyStraight(double v0, double dt, double azimuth) {
        
            // חישוב התזוזה בכל צעד זמן
            double dx = v0 * dt * cos(azimuth * PI / 180.0); // מרחק בציר X
            double dy = v0 * dt * sin(azimuth * PI / 180.0); // מרחק בציר Y

            // עדכון המיקום
            x += dx;
            y += dy;  
    }
    void printPosition(double time, ofstream& output_file) {
        output_file << fixed;
        output_file << time << " " << int(x) << " " << int(y) << " " << int(azimuth) << endl;
    }

    double getX() const { return x; }
    double getY() const { return y; }
    void setX(double curntX){
        x = curntX;
    }
    void sety(double curntY) {
        y = curntY;

    }
};

// Function to read simulation parameters from an INI file
void readIniFile(const string& filename, double& Dt, int& N_uav, double& R, double& X0, double& Y0, double& Z0, double& V0, double& Az, double& TimeLim) {
    ifstream file(filename);
    if (!file.is_open()) {
        throw runtime_error("Failed to open " + filename);
    }

    string line;
    while (getline(file, line)) {
        istringstream iss(line);
        string key;
        if (getline(iss, key, '=')) {
            string value;
            if (getline(iss, value)) {
                if (key == "Dt") {
                    Dt = stod(value);
                }
                else if (key == "N_uav") {
                    N_uav = stoi(value);
                }
                else if (key == "R") {
                    R = stod(value);
                }
                else if (key == "X0") {
                    X0 = stod(value);
                }
                else if (key == "Y0") {
                    Y0 = stod(value);
                }
                else if (key == "Z0") {
                    Z0 = stod(value);
                }
                else if (key == "V0") {
                    V0 = stod(value);
                }
                else if (key == "Az") {
                    Az = stod(value);
                }
                else if (key == "TimeLim") {
                    TimeLim = stod(value);
                }
                else {
                    throw runtime_error("Invalid parameter in " + filename + ": " + key);
                }
            }
        }
    }

    file.close();
}

// Function to read commands from a text file and sort them by time and number
vector<vector<double>> readAndSortCommands(const string& filename) {
    vector<vector<double>> commands;
    ifstream file(filename);
    if (!file.is_open()) {
        throw runtime_error("Failed to open " + filename);
    }

    double time, num, x, y;
    while (file >> time >> num >> x >> y) {
        commands.push_back({ time, num, x, y });
    }

    file.close();

    // Sort commands by time and number
    sort(commands.begin(), commands.end(), [](const vector<double>& a, const vector<double>& b) {
        if (a[0] == b[0]) { // If times are equal, sort by number
            return a[1] < b[1];
        }
        return a[0] < b[0]; // Otherwise, sort by time
        });

    return commands;
}

int main() {
    ifstream config_file("SimParams.ini");
    if (!config_file.is_open()) {
        cerr << "Failed to open SimParams.ini" << endl;
        return 1;
    }

    double Dt, R, X0, Y0, Z0, V0, Az, TimeLim;
    int N_uav;

    try {
        readIniFile("SimParams.ini", Dt, N_uav, R, X0, Y0, Z0, V0, Az, TimeLim);
        cout << "Simulation parameters read successfully." << endl;
    }
    catch (const exception& e) {
        cerr << "Error reading simulation parameters from SimParams.ini: " << e.what() << endl;
        return 1;
    }

    ifstream commands_file("SimCmds.txt");
    if (!commands_file.is_open()) {
        cerr << "Failed to open SimCmds.txt" << endl;
        return 1;
    }
    vector<vector<double>> commands;
    try {
        commands = readAndSortCommands("SimCmds.txt");
        cout << "Commands read successfully." << endl;
    }
    catch (const exception& e) {
        cerr << "Error reading commands from SimCmds.txt: " << e.what() << endl;
        return 1;
    }

    vector<Aircraft> aircrafts;

    for (int i = 0; i < N_uav; ++i) {
        aircrafts.push_back(Aircraft(X0, Y0, V0, R, Az));
    }

    vector<ofstream> output_files;
    for (int i = 0; i < N_uav; ++i) {
        string filename = "UAV" + to_string(i + 1) + ".txt";
        output_files.push_back(ofstream(filename));
        if (!output_files.back().is_open()) {
            cerr << "Failed to open " << filename << " for writing" << endl;
            return 1;
        }
    }

    double current_time = 0;
    static bool firstFly = true; 
    static bool new_command_received = false; 
    double x = 0;
    double y = 0;
    for (int i = 0; i < N_uav; i++) {
        int num = i; 
    while (current_time <= TimeLim) {
        
            for (const auto& cmd : commands) { 
                if (cmd[0] == current_time && cmd[1] == num) {
                     x=cmd[2];
                    y=cmd[3];
                    firstFly = false;
                    new_command_received = true; 
                }    
            }
            aircrafts[num].flyTo(x,y, current_time, Dt,V0, R,firstFly);
            aircrafts[num].printPosition(current_time, output_files[num]);
            current_time += Dt;
    }
    firstFly = true;
    new_command_received = false;
    current_time = 0;
    for (int i = 0; i < N_uav; ++i) {
        aircrafts.push_back(Aircraft(X0, Y0, V0, R, Az));
    }
    }

    for (auto& file : output_files) {
        file.close();
    }

    cout << "Simulation completed successfully." << endl;

    return 0;
}
